import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";
import type { InsertOrder } from "@shared/schema";

export function useOrders(search?: string) {
  return useQuery({
    queryKey: [api.orders.list.path, { search }],
    queryFn: async () => {
      const url = new URL(api.orders.list.path, window.location.origin);
      if (search) url.searchParams.append("search", search);
      
      const res = await fetch(url.toString(), { credentials: "include" });
      if (!res.ok) throw new Error("Error al cargar órdenes");
      return api.orders.list.responses[200].parse(await res.json());
    },
  });
}

export function useOrder(id: number) {
  return useQuery({
    queryKey: [api.orders.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.orders.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Error al cargar la orden");
      return api.orders.get.responses[200].parse(await res.json());
    },
    enabled: !!id,
  });
}

export function useClientOrders(dni: string) {
  return useQuery({
    queryKey: [api.orders.getByDni.path, dni],
    queryFn: async () => {
      const url = buildUrl(api.orders.getByDni.path, { dni });
      const res = await fetch(url);
      if (!res.ok) throw new Error("Error al cargar órdenes del cliente");
      return api.orders.getByDni.responses[200].parse(await res.json());
    },
    enabled: !!dni && dni.length > 5,
  });
}

export function useOrderStats() {
  return useQuery({
    queryKey: [api.orders.stats.path],
    queryFn: async () => {
      const res = await fetch(api.orders.stats.path, { credentials: "include" });
      if (!res.ok) throw new Error("Error al cargar estadísticas");
      return api.orders.stats.responses[200].parse(await res.json());
    },
  });
}

export function useCreateOrder() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: InsertOrder) => {
      const res = await fetch(api.orders.create.path, {
        method: api.orders.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) {
        if (res.status === 400) {
          const err = await res.json();
          throw new Error(err.message || "Error de validación");
        }
        throw new Error("Error al crear la orden");
      }
      return api.orders.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.orders.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.orders.stats.path] });
      toast({ title: "Éxito", description: "Orden creada correctamente." });
    },
    onError: (err: Error) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  });
}

export function useUpdateOrder() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ id, ...data }: Partial<InsertOrder> & { id: number }) => {
      const url = buildUrl(api.orders.update.path, { id });
      const res = await fetch(url, {
        method: api.orders.update.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Error al actualizar la orden");
      return api.orders.update.responses[200].parse(await res.json());
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [api.orders.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.orders.get.path, variables.id] });
      queryClient.invalidateQueries({ queryKey: [api.orders.stats.path] });
      toast({ title: "Éxito", description: "Orden actualizada." });
    },
    onError: (err: Error) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  });
}

export function useDeleteOrder() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.orders.delete.path, { id });
      const res = await fetch(url, {
        method: api.orders.delete.method,
        credentials: "include",
      });
      if (!res.ok) throw new Error("Error al eliminar la orden");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.orders.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.orders.stats.path] });
      toast({ title: "Éxito", description: "Orden eliminada." });
    },
    onError: (err: Error) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  });
}
