import { useState, useRef, useEffect } from "react";
import { useRoute } from "wouter";
import { useClientOrders } from "@/hooks/use-orders";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/ui/status-badge";
import { Wrench, Search, Smartphone, DollarSign, Download, PenTool } from "lucide-react";
import { format } from "date-fns";
import SignatureCanvas from "react-signature-canvas";
import { useReactToPrint } from "react-to-print";
import { TicketPrint } from "@/components/orders/TicketPrint";
import type { OrderResponse } from "@shared/schema";

export default function ClientPortal() {
  const [dniInput, setDniInput] = useState("");
  const [activeDni, setActiveDni] = useState("");
  
  // Try to get DNI from URL query params
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const urlDni = params.get('dni');
    if (urlDni) {
      setDniInput(urlDni);
      setActiveDni(urlDni);
    }
  }, []);

  const { data: orders, isLoading, error } = useClientOrders(activeDni);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (dniInput.trim().length > 5) {
      setActiveDni(dniInput.trim());
      // Update URL without reload
      const url = new URL(window.location.href);
      url.searchParams.set('dni', dniInput.trim());
      window.history.pushState({}, '', url);
    }
  };

  return (
    <div className="min-h-screen bg-background dark-fix relative overflow-hidden py-10 px-4 sm:px-6">
      {/* Background gradients */}
      <div className="absolute top-[-10%] right-[-5%] w-[50%] h-[50%] bg-primary/10 blur-[150px] rounded-full pointer-events-none" />
      <div className="absolute bottom-[-10%] left-[-5%] w-[50%] h-[50%] bg-blue-600/10 blur-[150px] rounded-full pointer-events-none" />

      <div className="max-w-4xl mx-auto relative z-10">
        <div className="text-center mb-10">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary to-purple-600 flex items-center justify-center shadow-lg shadow-primary/20 mx-auto mb-4 border border-white/10">
            <Wrench className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl md:text-5xl font-display font-bold text-white mb-3">Portal del Cliente</h1>
          <p className="text-white/60 max-w-lg mx-auto">Consulta el estado de tu reparación ingresando tu número de documento.</p>
        </div>

        <Card className="glass border-white/10 shadow-2xl mb-8">
          <CardContent className="p-2 sm:p-4">
            <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/40" />
                <Input 
                  placeholder="Ingresa tu DNI / Documento" 
                  value={dniInput}
                  onChange={(e) => setDniInput(e.target.value)}
                  className="pl-12 h-14 bg-black/40 border-white/10 focus:border-primary text-lg text-white rounded-xl"
                  required
                />
              </div>
              <Button type="submit" className="h-14 px-8 btn-gradient rounded-xl text-lg shrink-0">
                Consultar
              </Button>
            </form>
          </CardContent>
        </Card>

        {isLoading && (
          <div className="flex justify-center py-12">
            <div className="animate-spin w-10 h-10 border-4 border-primary border-t-transparent rounded-full"></div>
          </div>
        )}

        {error && (
          <Card className="glass border-red-500/20 bg-red-500/5">
            <CardContent className="p-6 text-center text-red-400">
              <p>Ocurrió un error al buscar las órdenes. Por favor intenta nuevamente.</p>
            </CardContent>
          </Card>
        )}

        {orders && orders.length === 0 && (
          <Card className="glass border-white/5 bg-white/[0.02]">
            <CardContent className="p-12 text-center">
              <Smartphone className="w-16 h-16 text-white/20 mx-auto mb-4" />
              <h3 className="text-xl font-medium text-white/80 mb-2">No tienes órdenes activas</h3>
              <p className="text-white/50">No encontramos ninguna reparación asociada al documento {activeDni}.</p>
            </CardContent>
          </Card>
        )}

        {orders && orders.length > 0 && (
          <div className="space-y-6">
            <h2 className="text-2xl font-display font-semibold text-white px-2">Mis Reparaciones ({orders.length})</h2>
            {orders.map(order => (
              <OrderClientCard key={order.id} order={order} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function OrderClientCard({ order }: { order: OrderResponse }) {
  const [showSignature, setShowSignature] = useState(false);
  const signatureRef = useRef<SignatureCanvas>(null);
  const [isSigned, setIsSigned] = useState(false);
  
  const printRef = useRef<HTMLDivElement>(null);
  const handlePrint = useReactToPrint({
    contentRef: printRef,
    documentTitle: `Ticket_TechFix_${order.id}`,
  });

  const saveSignature = () => {
    if (signatureRef.current && !signatureRef.current.isEmpty()) {
      setIsSigned(true);
      setShowSignature(false);
      // Here you would normally upload the base64 image to the backend
      // const dataURL = signatureRef.current.getTrimmedCanvas().toDataURL('image/png');
    }
  };

  return (
    <Card className="glass border-white/10 overflow-hidden transition-all duration-300 hover:border-white/20">
      <CardHeader className="bg-black/20 border-b border-white/5 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 p-5 sm:p-6">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <span className="text-sm font-mono text-primary bg-primary/10 px-2 py-1 rounded-md border border-primary/20">
              Orden #{order.id.toString().padStart(5, '0')}
            </span>
            <span className="text-sm text-white/50">{format(new Date(order.createdAt), "dd MMM yyyy")}</span>
          </div>
          <CardTitle className="text-xl text-white">{order.deviceModel}</CardTitle>
        </div>
        <StatusBadge status={order.status} className="text-sm py-1 px-3" />
      </CardHeader>
      
      <CardContent className="p-0">
        <div className="grid grid-cols-1 md:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-white/5">
          <div className="p-5 sm:p-6 md:col-span-2 space-y-4">
            <div>
              <p className="text-sm font-medium text-white/50 mb-1">Descripción del problema</p>
              <p className="text-white/90 bg-black/20 p-4 rounded-xl border border-white/5 leading-relaxed">
                {order.issueDescription}
              </p>
            </div>
            
            <div className="pt-2 flex flex-wrap gap-3">
              <Button 
                variant="outline" 
                className="gap-2 bg-white/5 border-white/10 hover:bg-white/10 text-white rounded-xl"
                onClick={() => handlePrint()}
              >
                <Download className="w-4 h-4" /> Descargar Ticket
              </Button>
              
              {order.status === "Entregado" && !isSigned && (
                <Button 
                  className="gap-2 btn-gradient rounded-xl"
                  onClick={() => setShowSignature(!showSignature)}
                >
                  <PenTool className="w-4 h-4" /> Firmar Recepción
                </Button>
              )}
              {isSigned && (
                <div className="flex items-center gap-2 px-4 py-2 bg-green-500/10 border border-green-500/20 text-green-400 rounded-xl text-sm font-medium">
                  ✓ Recepción firmada digitalmente
                </div>
              )}
            </div>

            {/* Signature Area */}
            {showSignature && (
              <div className="mt-4 p-4 border border-white/10 rounded-xl bg-black/40">
                <div className="flex justify-between items-center mb-2">
                  <p className="text-sm font-medium text-white/80">Firma digital de conformidad:</p>
                  <Button variant="ghost" size="sm" onClick={() => signatureRef.current?.clear()} className="h-8 text-white/50 hover:text-white">
                    Limpiar
                  </Button>
                </div>
                <div className="bg-white rounded-lg overflow-hidden border-2 border-white/20">
                  <SignatureCanvas 
                    ref={signatureRef} 
                    penColor="black"
                    canvasProps={{ className: "w-full h-40" }} 
                  />
                </div>
                <div className="flex justify-end gap-2 mt-4">
                  <Button variant="outline" className="border-white/10 text-white" onClick={() => setShowSignature(false)}>
                    Cancelar
                  </Button>
                  <Button className="btn-gradient" onClick={saveSignature}>
                    Confirmar Firma
                  </Button>
                </div>
              </div>
            )}
          </div>
          
          <div className="p-5 sm:p-6 bg-gradient-to-b from-transparent to-primary/5 flex flex-col justify-center">
            <h4 className="text-sm font-medium text-white/50 mb-4 flex items-center gap-2">
              <DollarSign className="w-4 h-4" /> Resumen de Costos
            </h4>
            <div className="space-y-3 mb-6">
              <div className="flex justify-between text-sm">
                <span className="text-white/60">Presupuesto</span>
                <span className="text-white font-medium">${order.estimatedCost.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-white/60">Seña Abonada</span>
                <span className="text-white font-medium">-${order.deposit.toFixed(2)}</span>
              </div>
              <div className="w-full h-px bg-white/10 my-2"></div>
              <div className="flex justify-between">
                <span className="text-white/90 font-medium">Saldo a Pagar</span>
                <span className={`font-bold text-lg ${order.balance > 0 ? 'text-primary' : 'text-emerald-400'}`}>
                  ${order.balance.toFixed(2)}
                </span>
              </div>
            </div>
            
            {order.balance > 0 && order.status === "Finalizado" && (
              <div className="bg-primary/10 border border-primary/20 rounded-xl p-3 text-center">
                <p className="text-xs text-primary font-medium">Tu equipo está listo. Recuerda abonar el saldo al retirar.</p>
              </div>
            )}
          </div>
        </div>
      </CardContent>

      <div className="hidden">
        <TicketPrint ref={printRef} order={order} />
      </div>
    </Card>
  );
}
