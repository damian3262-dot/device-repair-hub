import { useState } from "react";
import { Link } from "wouter";
import { AdminLayout } from "@/components/layout/AdminLayout";
import { useOrders, useCreateOrder } from "@/hooks/use-orders";
import { StatusBadge } from "@/components/ui/status-badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Search, Plus, ExternalLink } from "lucide-react";
import { OrderForm } from "@/components/orders/OrderForm";
import { format } from "date-fns";

export default function Orders() {
  const [search, setSearch] = useState("");
  const { data: orders, isLoading } = useOrders(search);
  const { mutate: createOrder, isPending: isCreating } = useCreateOrder();
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  return (
    <AdminLayout>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-white mb-2">Gestión de Órdenes</h1>
          <p className="text-white/60">Crea, busca y administra reparaciones.</p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="btn-gradient rounded-xl gap-2 shadow-lg">
              <Plus className="w-4 h-4" />
              Nueva Orden
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[700px] glass-panel border-white/10 text-white p-0 overflow-hidden">
            <DialogHeader className="p-6 pb-0">
              <DialogTitle className="text-2xl font-display">Ingresar Nueva Orden</DialogTitle>
            </DialogHeader>
            <div className="p-6 max-h-[80vh] overflow-y-auto">
              <OrderForm 
                onSubmit={(data) => {
                  createOrder(data, {
                    onSuccess: () => setIsDialogOpen(false)
                  });
                }} 
                isPending={isCreating} 
              />
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="glass border-white/5 mb-6">
        <CardContent className="p-4 flex items-center gap-3">
          <Search className="w-5 h-5 text-white/40" />
          <Input 
            placeholder="Buscar por cliente, teléfono, DNI o dispositivo..." 
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="border-0 bg-transparent text-white placeholder:text-white/40 focus-visible:ring-0 px-0 shadow-none text-lg"
          />
        </CardContent>
      </Card>

      {isLoading ? (
        <div className="flex justify-center p-12">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
        </div>
      ) : orders?.length === 0 ? (
        <div className="text-center py-20 bg-card/30 rounded-2xl border border-white/5 backdrop-blur-sm">
          <Wrench className="w-16 h-16 text-white/20 mx-auto mb-4" />
          <h3 className="text-xl font-medium text-white/80 mb-2">No se encontraron órdenes</h3>
          <p className="text-white/50">Prueba con otros términos de búsqueda o crea una nueva.</p>
        </div>
      ) : (
        <div className="grid gap-4">
          {orders?.map((order) => (
            <Link key={order.id} href={`/orders/${order.id}`}>
              <Card className="glass border-white/5 hover:bg-white/[0.02] hover:border-white/20 transition-all duration-300 cursor-pointer group">
                <CardContent className="p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="text-sm font-mono text-primary bg-primary/10 px-2 py-0.5 rounded-md">
                        #{order.id.toString().padStart(5, '0')}
                      </span>
                      <StatusBadge status={order.status} />
                      <span className="text-xs text-white/40">{format(new Date(order.createdAt), "dd MMM yyyy")}</span>
                    </div>
                    <h3 className="text-lg font-semibold text-white truncate">{order.customerName}</h3>
                    <p className="text-white/60 text-sm truncate">{order.deviceModel} • {order.phone}</p>
                  </div>
                  
                  <div className="flex items-center gap-6 md:gap-8 w-full md:w-auto border-t md:border-t-0 border-white/10 pt-4 md:pt-0">
                    <div className="text-right">
                      <p className="text-xs text-white/50 mb-1">Costo Total</p>
                      <p className="font-semibold text-white">${order.estimatedCost}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-white/50 mb-1">Saldo</p>
                      <p className={`font-semibold ${order.balance > 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                        ${order.balance}
                      </p>
                    </div>
                    <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center group-hover:bg-primary group-hover:text-white transition-colors text-white/40 border border-white/10">
                      <ExternalLink className="w-4 h-4" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </AdminLayout>
  );
}

// Just importing wrench here for the empty state
import { Wrench } from "lucide-react";
