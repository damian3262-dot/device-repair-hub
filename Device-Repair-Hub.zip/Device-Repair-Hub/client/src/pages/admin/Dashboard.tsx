import { AdminLayout } from "@/components/layout/AdminLayout";
import { useOrderStats } from "@/hooks/use-orders";
import { Card, CardContent } from "@/components/ui/card";
import { Wrench, CheckCircle2, Clock, DollarSign, Wallet } from "lucide-react";

export default function Dashboard() {
  const { data: stats, isLoading } = useOrderStats();

  if (isLoading) {
    return (
      <AdminLayout>
        <div className="flex h-[50vh] items-center justify-center">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
        </div>
      </AdminLayout>
    );
  }

  const statCards = [
    { title: "Total Órdenes", value: stats?.totalOrders || 0, icon: Wrench, color: "text-blue-400", bg: "bg-blue-400/10", border: "border-blue-400/20" },
    { title: "En Proceso", value: stats?.activeOrders || 0, icon: Clock, color: "text-amber-400", bg: "bg-amber-400/10", border: "border-amber-400/20" },
    { title: "Finalizadas", value: stats?.completedOrders || 0, icon: CheckCircle2, color: "text-emerald-400", bg: "bg-emerald-400/10", border: "border-emerald-400/20" },
    { title: "Ingresos Totales", value: `$${(stats?.totalRevenue || 0).toLocaleString()}`, icon: DollarSign, color: "text-purple-400", bg: "bg-purple-400/10", border: "border-purple-400/20" },
    { title: "Saldo Pendiente", value: `$${(stats?.pendingRevenue || 0).toLocaleString()}`, icon: Wallet, color: "text-rose-400", bg: "bg-rose-400/10", border: "border-rose-400/20" },
  ];

  return (
    <AdminLayout>
      <div className="mb-8">
        <h1 className="text-3xl font-display font-bold text-white mb-2">Panel de Control</h1>
        <p className="text-white/60">Resumen del estado de tu taller de reparaciones.</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
        {statCards.map((stat, i) => (
          <Card key={i} className={`glass overflow-hidden border ${stat.border} hover:-translate-y-1 transition-transform duration-300`}>
            <CardContent className="p-6 relative">
              <div className={`absolute top-0 right-0 p-4 rounded-bl-3xl ${stat.bg}`}>
                <stat.icon className={`w-6 h-6 ${stat.color} opacity-80`} />
              </div>
              <div className="relative z-10 pt-2">
                <p className="text-sm font-medium text-white/60 mb-1">{stat.title}</p>
                <h3 className={`text-3xl font-display font-bold ${stat.color} drop-shadow-[0_0_10px_rgba(255,255,255,0.1)]`}>
                  {stat.value}
                </h3>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="mt-12 grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="glass min-h-[300px] flex items-center justify-center border-white/5">
          <div className="text-center text-white/40">
            <Wrench className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>Gráfico de órdenes mensuales</p>
            <p className="text-sm">(Espacio para integración de Recharts)</p>
          </div>
        </Card>
        <Card className="glass min-h-[300px] flex items-center justify-center border-white/5">
          <div className="text-center text-white/40">
            <DollarSign className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>Evolución de ingresos</p>
            <p className="text-sm">(Espacio para integración de Recharts)</p>
          </div>
        </Card>
      </div>
    </AdminLayout>
  );
}
