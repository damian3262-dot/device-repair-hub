import { useRef, useState } from "react";
import { useRoute, Link } from "wouter";
import { AdminLayout } from "@/components/layout/AdminLayout";
import { useOrder, useUpdateOrder, useDeleteOrder } from "@/hooks/use-orders";
import { StatusBadge } from "@/components/ui/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { OrderForm } from "@/components/orders/OrderForm";
import { TicketPrint } from "@/components/orders/TicketPrint";
import { format } from "date-fns";
import QRCode from "react-qr-code";
import { useReactToPrint } from "react-to-print";
import {
  ArrowLeft,
  Printer,
  MessageCircle,
  Edit,
  Trash2,
  Smartphone,
  User,
  FileText,
  DollarSign,
} from "lucide-react";

export default function OrderDetail() {
  const [, params] = useRoute("/orders/:id");
  const id = Number(params?.id);
  const { data: order, isLoading } = useOrder(id);
  const { mutate: updateOrder, isPending: isUpdating } = useUpdateOrder();
  const { mutate: deleteOrder, isPending: isDeleting } = useDeleteOrder();

  const [isEditOpen, setIsEditOpen] = useState(false);
  const printRef = useRef<HTMLDivElement>(null);

  const handlePrint = useReactToPrint({
    contentRef: printRef,
    documentTitle: `Orden_${id.toString().padStart(5, "0")}`,
  });

  if (isLoading) {
    return (
      <AdminLayout>
        <div className="flex h-[50vh] items-center justify-center">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
        </div>
      </AdminLayout>
    );
  }

  if (!order) {
    return (
      <AdminLayout>
        <div className="text-center py-20">
          <h2 className="text-2xl text-white">Orden no encontrada</h2>
          <Button asChild variant="link" className="mt-4 text-primary">
            <Link href="/orders">Volver a órdenes</Link>
          </Button>
        </div>
      </AdminLayout>
    );
  }

  const clientUrl = `${window.location.origin}/client?dni=${order.clientDni}`;
  const whatsappMsg = encodeURIComponent(
    `Hola ${order.customerName}, te escribimos de TechFix. Tu orden #${order.id} de reparación para ${order.deviceModel} está en estado: ${order.status}. Puedes ver el detalle aquí: ${clientUrl}`,
  );

  return (
    <AdminLayout>
      <div className="mb-6 flex items-center gap-4">
        <Button
          asChild
          variant="outline"
          size="icon"
          className="glass border-white/10 text-white hover:bg-white/10 rounded-full"
        >
          <Link href="/orders">
            <ArrowLeft className="w-4 h-4" />
          </Link>
        </Button>
        <div>
          <h1 className="text-2xl md:text-3xl font-display font-bold text-white flex items-center gap-3">
            Orden #{order.id.toString().padStart(5, "0")}
            <StatusBadge status={order.status} className="text-sm" />
          </h1>
          <p className="text-white/50 text-sm mt-1">
            Ingresada el {format(new Date(order.createdAt), "dd/MM/yyyy HH:mm")}
          </p>
        </div>

        <div className="ml-auto flex items-center gap-2">
          <Button
            variant="outline"
            className="hidden md:flex gap-2 glass border-white/10 text-white hover:bg-green-500/20 hover:text-green-400 hover:border-green-500/50 transition-colors"
            onClick={() =>
              window.open(
                `https://wa.me/${order.phone.replace(/\D/g, "")}?text=${whatsappMsg}`,
                "_blank",
              )
            }
          >
            <MessageCircle className="w-4 h-4" />
            Notificar
          </Button>
          <Button
            variant="outline"
            className="gap-2 glass border-white/10 text-white hover:bg-blue-500/20 hover:text-blue-400 hover:border-blue-500/50 transition-colors"
            onClick={() => handlePrint()}
          >
            <Printer className="w-4 h-4" />
            <span className="hidden md:inline">Imprimir Ticket</span>
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Info */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="glass border-white/5 overflow-hidden">
            <CardHeader className="border-b border-white/5 bg-black/20 pb-4">
              <CardTitle className="text-lg flex items-center gap-2 text-white/90">
                <User className="w-5 h-5 text-primary" /> Datos del Cliente
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <p className="text-sm text-white/40 mb-1">Nombre Completo</p>
                <p className="text-lg text-white font-medium">
                  {order.customerName}
                </p>
              </div>
              <div>
                <p className="text-sm text-white/40 mb-1">DNI</p>
                <p className="text-lg text-white font-medium">
                  {order.clientDni}
                </p>
              </div>
              <div>
                <p className="text-sm text-white/40 mb-1">Teléfono</p>
                <p className="text-lg text-white font-medium">{order.phone}</p>
              </div>
            </CardContent>
          </Card>

          <Card className="glass border-white/5 overflow-hidden">
            <CardHeader className="border-b border-white/5 bg-black/20 pb-4">
              <CardTitle className="text-lg flex items-center gap-2 text-white/90">
                <Smartphone className="w-5 h-5 text-primary" /> Detalles del
                Equipo
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-white/40 mb-1">
                    Tipo de Dispositivo
                  </p>
                  <p className="text-lg text-white font-medium">
                    {order.deviceType}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-white/40 mb-1">Modelo</p>
                  <p className="text-lg text-white font-medium">
                    {order.deviceModel}
                  </p>
                </div>
              </div>

              <div>
                <p className="text-sm text-white/40 mb-2">
                  Checklist de Ingreso
                </p>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  {[
                    { key: "powersOn", label: "Enciende" },
                    { key: "charges", label: "Carga" },
                    { key: "hasAudio", label: "Audio" },
                    { key: "screenIntact", label: "Pantalla" },
                    { key: "touchWorks", label: "Touch" },
                    { key: "buttonsWork", label: "Botones" },
                  ].map((item) => (
                    <div
                      key={item.key}
                      className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/5 border border-white/5"
                    >
                      <div
                        className={`w-2 h-2 rounded-full ${order.checklist[item.key as keyof typeof order.checklist] ? "bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]" : "bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.5)]"}`}
                      />
                      <span className="text-xs text-white/70">
                        {item.label}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <p className="text-sm text-white/40 mb-2 flex items-center gap-2">
                  <FileText className="w-4 h-4" /> Descripción del problema
                </p>
                <div className="bg-black/30 p-4 rounded-xl border border-white/5">
                  <p className="text-white/80 whitespace-pre-wrap leading-relaxed">
                    {order.issueDescription}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar Info */}
        <div className="space-y-6">
          <Card className="glass border-white/5 bg-gradient-to-b from-card/60 to-primary/5">
            <CardHeader className="border-b border-white/5 pb-4">
              <CardTitle className="text-lg flex items-center gap-2 text-white/90">
                <DollarSign className="w-5 h-5 text-primary" /> Finanzas
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6 space-y-4">
              <div className="flex justify-between items-center pb-4 border-b border-white/5">
                <span className="text-white/60">Costo Estimado</span>
                <span className="text-xl text-white font-medium">
                  ${order.estimatedCost.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between items-center pb-4 border-b border-white/5">
                <span className="text-white/60">Seña / Depósito</span>
                <span className="text-xl text-white font-medium">
                  ${order.deposit.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between items-center pt-2">
                <span className="text-white/80 font-medium">
                  Saldo Pendiente
                </span>
                <span
                  className={`text-2xl font-bold ${order.balance > 0 ? "text-rose-400" : "text-emerald-400"}`}
                >
                  ${order.balance.toFixed(2)}
                </span>
              </div>
            </CardContent>
          </Card>

          <Card className="glass border-white/5">
            <CardContent className="p-6 text-center">
              <p className="text-sm text-white/60 mb-4">
                Código QR para seguimiento
              </p>
              <div className="bg-white p-4 rounded-xl inline-block mb-4">
                <QRCode value={clientUrl} size={150} />
              </div>
              <p className="text-xs text-white/40 break-all">{clientUrl}</p>
            </CardContent>
          </Card>

          <div className="flex flex-col gap-3">
            <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
              <DialogTrigger asChild>
                <Button
                  variant="outline"
                  className="w-full glass border-white/10 text-white hover:bg-white/10 rounded-xl gap-2"
                >
                  <Edit className="w-4 h-4" /> Editar Orden
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[700px] glass-panel border-white/10 text-white p-0 overflow-hidden">
                <DialogHeader className="p-6 pb-0">
                  <DialogTitle className="text-2xl font-display">
                    Editar Orden #{order.id}
                  </DialogTitle>
                </DialogHeader>
                <div className="p-6 max-h-[80vh] overflow-y-auto">
                  <OrderForm
                    defaultValues={order}
                    onSubmit={(data) => {
                      updateOrder(
                        { id: order.id, ...data },
                        {
                          onSuccess: () => setIsEditOpen(false),
                        },
                      );
                    }}
                    isPending={isUpdating}
                  />
                </div>
              </DialogContent>
            </Dialog>

            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button
                  variant="outline"
                  className="w-full border-red-500/30 text-red-400 hover:bg-red-500/10 rounded-xl gap-2"
                >
                  <Trash2 className="w-4 h-4" /> Eliminar Orden
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent className="glass-panel border-red-500/20">
                <AlertDialogHeader>
                  <AlertDialogTitle className="text-white">
                    ¿Estás seguro?
                  </AlertDialogTitle>
                  <AlertDialogDescription className="text-white/60">
                    Esta acción no se puede deshacer. Esto eliminará
                    permanentemente la orden de reparación y todos sus datos
                    asociados.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel className="bg-white/5 border-white/10 text-white hover:bg-white/10 hover:text-white">
                    Cancelar
                  </AlertDialogCancel>
                  <AlertDialogAction
                    className="bg-red-600 hover:bg-red-700 text-white"
                    onClick={() => {
                      deleteOrder(order.id, {
                        onSuccess: () => {
                          window.location.href = "/orders";
                        },
                      });
                    }}
                  >
                    {isDeleting ? "Eliminando..." : "Sí, eliminar"}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
      </div>

      {/* Hidden Print Component */}
      <div className="hidden">
        <TicketPrint ref={printRef} order={order} />
      </div>
    </AdminLayout>
  );
}
