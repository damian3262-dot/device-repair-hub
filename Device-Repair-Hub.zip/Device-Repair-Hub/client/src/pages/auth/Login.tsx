import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Wrench } from "lucide-react";

export default function Login() {
  const { login, isLoggingIn } = useAuth();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    login({ username, password });
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 relative overflow-hidden bg-background dark-fix">
      {/* Abstract Background Elements */}
      <div className="absolute top-[-20%] left-[-10%] w-[70%] h-[70%] bg-primary/20 blur-[150px] rounded-full pointer-events-none" />
      <div className="absolute bottom-[-20%] right-[-10%] w-[70%] h-[70%] bg-purple-600/20 blur-[150px] rounded-full pointer-events-none" />

      <div className="mb-8 text-center z-10">
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary to-purple-600 flex items-center justify-center shadow-2xl shadow-primary/30 mx-auto mb-4 border border-white/10">
          <Wrench className="w-8 h-8 text-white" />
        </div>
        <h1 className="text-4xl md:text-5xl font-display font-bold text-white mb-2 tracking-tight">TechFix Admin</h1>
        <p className="text-white/60">Sistema de Gestión de Reparaciones</p>
      </div>

      <Card className="w-full max-w-md glass border-white/10 shadow-2xl z-10">
        <CardHeader className="space-y-1 pb-6 text-center border-b border-white/5 bg-black/10">
          <CardTitle className="text-2xl font-display text-white">Iniciar Sesión</CardTitle>
          <CardDescription className="text-white/50">
            Ingresa tus credenciales para acceder al panel
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6 px-8 pb-8">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-2">
              <label className="text-sm font-medium text-white/80" htmlFor="username">
                Usuario
              </label>
              <Input
                id="username"
                type="text"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="h-12 bg-black/40 border-white/10 focus:border-primary text-white rounded-xl"
                placeholder="admin"
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium text-white/80" htmlFor="password">
                  Contraseña
                </label>
              </div>
              <Input
                id="password"
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="h-12 bg-black/40 border-white/10 focus:border-primary text-white rounded-xl"
                placeholder="••••••••"
              />
            </div>
            <Button 
              type="submit" 
              className="w-full h-12 btn-gradient rounded-xl text-lg font-medium mt-4"
              disabled={isLoggingIn}
            >
              {isLoggingIn ? "Verificando..." : "Ingresar"}
            </Button>
          </form>
        </CardContent>
      </Card>
      
      <div className="mt-8 text-white/40 text-sm z-10">
        <p>© {new Date().getFullYear()} TechFix Solutions.</p>
      </div>
    </div>
  );
}
