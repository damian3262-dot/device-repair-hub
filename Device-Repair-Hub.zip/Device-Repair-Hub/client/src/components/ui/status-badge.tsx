import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

const statusConfig: Record<string, { color: string, label: string }> = {
  "Recibido": { color: "bg-blue-500/10 text-blue-500 border-blue-500/20 hover:bg-blue-500/20", label: "Recibido" },
  "En reparación": { color: "bg-yellow-500/10 text-yellow-500 border-yellow-500/20 hover:bg-yellow-500/20", label: "En reparación" },
  "Esperando repuestos": { color: "bg-purple-500/10 text-purple-500 border-purple-500/20 hover:bg-purple-500/20", label: "Esperando repuestos" },
  "Finalizado": { color: "bg-green-500/10 text-green-500 border-green-500/20 hover:bg-green-500/20", label: "Finalizado" },
  "Entregado": { color: "bg-emerald-500/10 text-emerald-500 border-emerald-500/20 hover:bg-emerald-500/20", label: "Entregado" },
  "Irreparable": { color: "bg-red-500/10 text-red-500 border-red-500/20 hover:bg-red-500/20", label: "Irreparable" },
};

interface StatusBadgeProps {
  status: string;
  className?: string;
}

export function StatusBadge({ status, className }: StatusBadgeProps) {
  const config = statusConfig[status] || { color: "bg-gray-500/10 text-gray-500 border-gray-500/20", label: status };

  return (
    <Badge 
      variant="outline" 
      className={cn("font-medium transition-colors no-default-hover-elevate", config.color, className)}
    >
      {config.label}
    </Badge>
  );
}
