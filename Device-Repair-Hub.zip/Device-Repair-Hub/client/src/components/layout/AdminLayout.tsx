import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { 
  Sidebar, 
  SidebarContent, 
  SidebarGroup, 
  SidebarGroupContent, 
  SidebarGroupLabel, 
  SidebarMenu, 
  SidebarMenuButton, 
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
  SidebarHeader
} from "@/components/ui/sidebar";
import { LayoutDashboard, Wrench, LogOut, Users } from "lucide-react";
import { Button } from "@/components/ui/button";

export function AdminLayout({ children }: { children: React.ReactNode }) {
  const { user, isLoading, logout } = useAuth();
  const [location] = useLocation();

  if (isLoading) {
    return <div className="flex h-screen items-center justify-center bg-background"><div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div></div>;
  }

  if (!user) {
    window.location.href = "/login";
    return null;
  }

  const navItems = [
    { title: "Dashboard", url: "/", icon: LayoutDashboard },
    { title: "Órdenes", url: "/orders", icon: Wrench },
  ];

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full bg-background dark-fix">
        <Sidebar variant="inset" className="border-r border-white/10 glass-panel">
          <SidebarHeader className="p-4 flex flex-row items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-purple-600 flex items-center justify-center shadow-lg shadow-primary/20">
              <Wrench className="w-4 h-4 text-white" />
            </div>
            <span className="font-display font-bold text-xl text-gradient">TechFix</span>
          </SidebarHeader>
          <SidebarContent>
            <SidebarGroup>
              <SidebarGroupLabel className="text-white/50">Gestión</SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {navItems.map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton 
                        asChild 
                        isActive={location === item.url || (item.url !== "/" && location.startsWith(item.url))}
                        className="hover:bg-white/5 data-[active=true]:bg-primary/20 data-[active=true]:text-primary transition-all duration-200 rounded-xl mx-2"
                      >
                        <Link href={item.url} className="flex items-center gap-3 px-3 py-2">
                          <item.icon className="w-5 h-5" />
                          <span className="font-medium">{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>
          <div className="mt-auto p-4 border-t border-white/10">
            <div className="flex items-center gap-3 mb-4 px-2">
              <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center border border-white/20">
                <Users className="w-4 h-4 text-white/70" />
              </div>
              <div className="flex flex-col">
                <span className="text-sm font-semibold text-white/90">{user.username}</span>
                <span className="text-xs text-white/50">Administrador</span>
              </div>
            </div>
            <Button 
              variant="outline" 
              className="w-full justify-start gap-2 border-white/10 hover:bg-white/5 hover:text-white rounded-xl"
              onClick={() => logout()}
            >
              <LogOut className="w-4 h-4" />
              Cerrar Sesión
            </Button>
          </div>
        </Sidebar>

        <div className="flex flex-col flex-1 overflow-hidden relative">
          {/* Decorative background glow */}
          <div className="absolute top-[-10%] right-[-5%] w-[40%] h-[40%] bg-primary/10 blur-[120px] rounded-full pointer-events-none" />
          <div className="absolute bottom-[-10%] left-[-5%] w-[40%] h-[40%] bg-purple-600/10 blur-[120px] rounded-full pointer-events-none" />
          
          <header className="flex h-16 shrink-0 items-center gap-2 border-b border-white/10 px-4 glass sticky top-0 z-10">
            <SidebarTrigger className="text-white/70 hover:text-white" />
            <div className="ml-auto flex items-center gap-4">
              <Button asChild variant="ghost" size="sm" className="border border-primary/30 text-primary hover:bg-primary/10 rounded-full">
                <Link href="/client" target="_blank">Ver Portal Cliente</Link>
              </Button>
            </div>
          </header>
          <main className="flex-1 overflow-auto p-4 md:p-6 lg:p-8 z-0">
            <div className="mx-auto max-w-6xl">
              {children}
            </div>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
