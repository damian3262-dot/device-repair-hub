import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { orderStatuses, deviceTypes, type InsertOrder, type OrderResponse } from "@shared/schema";

const orderFormSchema = z.object({
  customerName: z.string().min(2, "Nombre muy corto"),
  clientDni: z.string().min(5, "DNI inválido"),
  phone: z.string().min(6, "Teléfono inválido"),
  deviceType: z.enum(deviceTypes),
  deviceModel: z.string().min(2, "Modelo requerido"),
  issueDescription: z.string().min(5, "Descripción muy corta"),
  checklist: z.object({
    powersOn: z.boolean(),
    charges: z.boolean(),
    hasAudio: z.boolean(),
    screenIntact: z.boolean(),
    touchWorks: z.boolean(),
    buttonsWork: z.boolean(),
  }),
  estimatedCost: z.coerce.number().min(0, "Costo debe ser positivo"),
  deposit: z.coerce.number().min(0, "Depósito debe ser positivo"),
  status: z.enum(orderStatuses),
});

interface OrderFormProps {
  defaultValues?: Partial<OrderResponse>;
  onSubmit: (data: InsertOrder) => void;
  isPending: boolean;
}

export function OrderForm({ defaultValues, onSubmit, isPending }: OrderFormProps) {
  const form = useForm<z.infer<typeof orderFormSchema>>({
    resolver: zodResolver(orderFormSchema),
    defaultValues: {
      customerName: defaultValues?.customerName || "",
      clientDni: defaultValues?.clientDni || "",
      phone: defaultValues?.phone || "",
      deviceType: (defaultValues?.deviceType as any) || "Smartphone",
      deviceModel: defaultValues?.deviceModel || "",
      issueDescription: defaultValues?.issueDescription || "",
      checklist: defaultValues?.checklist || {
        powersOn: false,
        charges: false,
        hasAudio: false,
        screenIntact: false,
        touchWorks: false,
        buttonsWork: false,
      },
      estimatedCost: defaultValues?.estimatedCost || 0,
      deposit: defaultValues?.deposit || 0,
      status: defaultValues?.status || "Recibido",
    },
  });

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="customerName"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-white/80">Nombre del Cliente</FormLabel>
                <FormControl>
                  <Input placeholder="Ej. Juan Pérez" {...field} className="bg-background/50 border-white/10 focus:border-primary rounded-xl" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="clientDni"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-white/80">DNI</FormLabel>
                <FormControl>
                  <Input placeholder="Ej. 12345678" {...field} className="bg-background/50 border-white/10 focus:border-primary rounded-xl" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="phone"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-white/80">Teléfono</FormLabel>
                <FormControl>
                  <Input placeholder="Ej. +34 600..." {...field} className="bg-background/50 border-white/10 focus:border-primary rounded-xl" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="deviceType"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-white/80">Tipo de Dispositivo</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger className="bg-background/50 border-white/10 focus:border-primary rounded-xl">
                      <SelectValue placeholder="Selecciona tipo" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent className="bg-card border-white/10">
                    {deviceTypes.map(type => (
                      <SelectItem key={type} value={type}>{type}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="deviceModel"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-white/80">Modelo de Dispositivo</FormLabel>
                <FormControl>
                  <Input placeholder="Ej. iPhone 13 Pro" {...field} className="bg-background/50 border-white/10 focus:border-primary rounded-xl" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="space-y-4">
          <FormLabel className="text-white/80">Checklist de Ingreso</FormLabel>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 p-4 rounded-xl border border-white/5 bg-black/20">
            {[
              { id: "powersOn", label: "Enciende" },
              { id: "charges", label: "Carga" },
              { id: "hasAudio", label: "Tiene Audio" },
              { id: "screenIntact", label: "Pantalla Sana" },
              { id: "touchWorks", label: "Touch funciona" },
              { id: "buttonsWork", label: "Botones funcionan" },
            ].map((item) => (
              <FormField
                key={item.id}
                control={form.control}
                name={`checklist.${item.id}` as any}
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <FormLabel className="font-normal text-white/70">
                      {item.label}
                    </FormLabel>
                  </FormItem>
                )}
              />
            ))}
          </div>
        </div>

        <FormField
          control={form.control}
          name="issueDescription"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="text-white/80">Descripción del Problema</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="Detalla el problema que reporta el cliente..." 
                  className="min-h-[100px] bg-background/50 border-white/10 focus:border-primary rounded-xl resize-none" 
                  {...field} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 rounded-xl border border-white/5 bg-black/20">
          <FormField
            control={form.control}
            name="estimatedCost"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-white/80">Costo Estimado ($)</FormLabel>
                <FormControl>
                  <Input type="number" {...field} className="bg-background/50 border-white/10 focus:border-primary rounded-xl" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="deposit"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-white/80">Seña / Depósito ($)</FormLabel>
                <FormControl>
                  <Input type="number" {...field} className="bg-background/50 border-white/10 focus:border-primary rounded-xl" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="status"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-white/80">Estado</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger className="bg-background/50 border-white/10 focus:border-primary rounded-xl">
                      <SelectValue placeholder="Selecciona un estado" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent className="bg-card border-white/10">
                    {orderStatuses.map(status => (
                      <SelectItem key={status} value={status}>{status}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="flex justify-end gap-3 pt-4 border-t border-white/10">
          <Button type="submit" disabled={isPending} className="btn-gradient rounded-xl px-8">
            {isPending ? "Guardando..." : "Guardar Orden"}
          </Button>
        </div>
      </form>
    </Form>
  );
}
