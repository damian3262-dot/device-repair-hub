import { forwardRef } from "react";
import QRCode from "react-qr-code";
import type { OrderResponse } from "@shared/schema";
import { format } from "date-fns";

interface TicketPrintProps {
  order: OrderResponse;
}

export const TicketPrint = forwardRef<HTMLDivElement, TicketPrintProps>(({ order }, ref) => {
  const clientUrl = `${window.location.origin}/client?dni=${order.clientDni}`;

  return (
    <div className="hidden print:block">
      <div ref={ref} className="p-8 max-w-[800px] mx-auto bg-white text-black font-sans">
        {/* Header */}
        <div className="flex justify-between items-start border-b-2 border-gray-200 pb-6 mb-6">
          <div>
            <h1 className="text-4xl font-bold font-display mb-1">TechFix</h1>
            <p className="text-gray-500">Servicio Técnico Especializado</p>
          </div>
          <div className="text-right">
            <h2 className="text-2xl font-bold text-gray-800">Orden #{order.id.toString().padStart(5, '0')}</h2>
            <p className="text-gray-500">{format(new Date(order.createdAt), "dd/MM/yyyy HH:mm")}</p>
          </div>
        </div>

        {/* Info Grid */}
        <div className="grid grid-cols-2 gap-8 mb-8">
          <div>
            <h3 className="text-lg font-bold mb-3 border-b pb-1">Datos del Cliente</h3>
            <p className="mb-1"><span className="font-semibold w-24 inline-block">Nombre:</span> {order.customerName}</p>
            <p className="mb-1"><span className="font-semibold w-24 inline-block">DNI:</span> {order.clientDni}</p>
            <p className="mb-1"><span className="font-semibold w-24 inline-block">Teléfono:</span> {order.phone}</p>
          </div>
          <div>
            <h3 className="text-lg font-bold mb-3 border-b pb-1">Dispositivo</h3>
            <p className="mb-1"><span className="font-semibold w-24 inline-block">Modelo:</span> {order.deviceModel}</p>
            <p className="mb-1"><span className="font-semibold w-24 inline-block">Estado:</span> {order.status}</p>
          </div>
        </div>

        {/* Description */}
        <div className="mb-8">
          <h3 className="text-lg font-bold mb-2 border-b pb-1">Descripción del Problema</h3>
          <p className="text-gray-700 bg-gray-50 p-4 rounded-lg whitespace-pre-wrap">
            {order.issueDescription}
          </p>
        </div>

        {/* Costs & QR */}
        <div className="flex justify-between items-end border-t-2 border-gray-200 pt-6 mt-8">
          <div className="flex gap-6 items-center">
            <div className="p-2 border-2 border-dashed border-gray-300 rounded-xl">
              <QRCode value={clientUrl} size={100} />
            </div>
            <div>
              <p className="font-bold text-sm mb-1">Escanea para seguir tu orden</p>
              <p className="text-xs text-gray-500">O ingresa a nuestro portal con tu DNI</p>
            </div>
          </div>
          <div className="bg-gray-50 p-6 rounded-xl min-w-[250px]">
            <div className="flex justify-between mb-2">
              <span className="text-gray-600">Presupuesto Estimado:</span>
              <span className="font-semibold">${order.estimatedCost.toFixed(2)}</span>
            </div>
            <div className="flex justify-between mb-2 pb-2 border-b">
              <span className="text-gray-600">Seña Abonada:</span>
              <span className="font-semibold">${order.deposit.toFixed(2)}</span>
            </div>
            <div className="flex justify-between mt-2 text-xl font-bold">
              <span>Saldo a Pagar:</span>
              <span>${order.balance.toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-12 text-center text-sm text-gray-400 border-t pt-4">
          <p>La revisión del equipo puede tener cargos adicionales si se detectan fallas no reportadas.</p>
          <p>Pasados los 90 días de la notificación de reparación, la empresa no se hace responsable por el equipo.</p>
        </div>
      </div>
    </div>
  );
});
TicketPrint.displayName = 'TicketPrint';
