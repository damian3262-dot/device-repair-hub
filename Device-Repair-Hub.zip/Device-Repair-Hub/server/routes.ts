import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Setup session
  app.use(session({
    cookie: { maxAge: 86400000 },
    store: new MemoryStore({
      checkPeriod: 86400000 
    }),
    resave: false,
    saveUninitialized: false,
    secret: process.env.SESSION_SECRET || 'reparaciones-secret'
  }));

  // Auth routes
  app.post(api.auth.login.path, async (req, res) => {
    try {
      const { username, password } = api.auth.login.input.parse(req.body);
      // Hardcoded admin for MVP
      if (username === 'admin' && password === 'admin') {
        (req.session as any).isAdmin = true;
        res.status(200).json({ message: "Logged in successfully" });
      } else {
        res.status(401).json({ message: "Invalid credentials" });
      }
    } catch(err) {
      res.status(400).json({ message: "Bad request" });
    }
  });

  app.post(api.auth.logout.path, async (req, res) => {
    req.session.destroy(() => {
      res.status(200).json({ message: "Logged out" });
    });
  });

  app.get(api.auth.me.path, async (req, res) => {
    if ((req.session as any).isAdmin) {
      res.status(200).json({ username: "admin" });
    } else {
      res.status(401).json({ message: "Not logged in" });
    }
  });

  // Orders routes
  app.get(api.orders.list.path, async (req, res) => {
    if (!(req.session as any).isAdmin) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    const search = req.query.search as string;
    const orders = await storage.getOrders(search);
    res.json(orders);
  });

  app.get(api.orders.stats.path, async (req, res) => {
    if (!(req.session as any).isAdmin) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    const stats = await storage.getStats();
    res.json(stats);
  });

  app.get(api.orders.getByDni.path, async (req, res) => {
    const orders = await storage.getOrdersByDni(req.params.dni);
    res.json(orders);
  });

  app.get(api.orders.get.path, async (req, res) => {
    const order = await storage.getOrder(Number(req.params.id));
    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }
    res.json(order);
  });

  app.post(api.orders.create.path, async (req, res) => {
    if (!(req.session as any).isAdmin) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    try {
      const bodySchema = api.orders.create.input.extend({
        estimatedCost: z.coerce.number(),
        deposit: z.coerce.number(),
      });
      const input = bodySchema.parse(req.body);
      const order = await storage.createOrder(input);
      res.status(201).json(order);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.patch(api.orders.update.path, async (req, res) => {
    if (!(req.session as any).isAdmin) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    try {
      const bodySchema = api.orders.update.input.extend({
        estimatedCost: z.coerce.number().optional(),
        deposit: z.coerce.number().optional(),
      });
      const input = bodySchema.parse(req.body);
      const order = await storage.updateOrder(Number(req.params.id), input);
      
      // Automatic WhatsApp notification simulation
      const clientUrl = `${req.get('origin')}/client?dni=${order.clientDni}`;
      const message = `Hola ${order.customerName}, tu orden #${order.id} ha sido actualizada. Estado: ${order.status}. Ver detalle: ${clientUrl}`;
      console.log(`[WhatsApp Notification to ${order.phone}]: ${message}`);

      res.status(200).json(order);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.delete(api.orders.delete.path, async (req, res) => {
    if (!(req.session as any).isAdmin) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    await storage.deleteOrder(Number(req.params.id));
    res.status(204).send();
  });

  // Seed db initially if empty
  const existing = await storage.getOrders();
  if (existing.length === 0) {
    await storage.createOrder({
      customerName: "Juan Pérez",
      clientDni: "12345678",
      phone: "+34600123456",
      deviceModel: "Samsung Galaxy S21",
      issueDescription: "Pantalla rota y no carga",
      estimatedCost: 15000,
      deposit: 5000,
      status: "Recibido"
    });
    await storage.createOrder({
      customerName: "María Gómez",
      clientDni: "87654321",
      phone: "+34600987654",
      deviceModel: "iPhone 13",
      issueDescription: "Cambio de batería",
      estimatedCost: 8000,
      deposit: 8000,
      status: "Entregado"
    });
  }

  return httpServer;
}
